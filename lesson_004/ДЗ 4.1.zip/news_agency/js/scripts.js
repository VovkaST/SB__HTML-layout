const FIXER_API_KEY = 'ea7f5d9b33e8b3b0d242b9b773e60ccb'
const FIXER_URL = 'http://data.fixer.io/api/latest'

function collectRates() {
    let rates = $('.rates')
    let euro = rates.find('.rate.euro')
    let dollar = rates.find('.rate.dollar')
    $.ajax({
        url: FIXER_URL,
        data: {'access_key': FIXER_API_KEY},
        method: 'GET',
        success: function(resp) {
            if (resp.success) {
                let _date = resp.date.split('-');
                _date = _date[2] + '.' + _date[1] + '.' + _date[0];
                let _e = resp.rates.RUB.toFixed(2)
                let _d = resp.rates.USD.toFixed(2)
                euro.attr('title', 'Курс Рубля к Евро на ' + _date)
                    .children('.cost').text(_e);
                dollar.attr('title', 'Курс Рубля к Доллару США на ' + _date)
                      .children('.cost').text((_e / _d).toFixed(2));
            } else {
                console.log('FIXER ERROR (' + resp.error.code + '): ' + resp.error.info);
            }
        },
        error: function(error) {
            euro.children('.cost').html('&mdash;');
            dollar.children('.cost').html('&mdash;');
            console.log(error);
        }
    });
}

$(function(){
    collectRates();
});